from . import PlaySound_dir
def play(sound):
      PlaySound_dir.playsound(sound)
